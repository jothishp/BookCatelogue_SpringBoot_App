package com.jothish.BookCatalogue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookCatalogueApplicationTests {

	@Test
	void contextLoads() {
	}

}
