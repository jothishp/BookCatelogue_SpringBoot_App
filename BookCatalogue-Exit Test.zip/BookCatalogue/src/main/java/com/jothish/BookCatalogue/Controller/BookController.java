package com.jothish.BookCatalogue.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.jothish.BookCatalogue.dao.BookRepo;
import com.jothish.BookCatalogue.model.Book;

@SpringBootApplication
@RestController
public class BookController {

	@Autowired
	public BookRepo booksrepo;
	

	
	
	@PostMapping("/books")
	public Book addBooks(@RequestBody Book book) {
		return booksrepo.save(book);
	}

	
	@PutMapping("/books")
	public Book updateBook(@RequestBody Book book){
		booksrepo.save(book);
		return book;
	}
	

 	@DeleteMapping("/books/{iSBN}")
	public String deleteBook(@PathVariable String iSBN) {
		 Book a =booksrepo.getOne(Integer.parseInt(iSBN));
		  booksrepo.delete(a);
		  return "deleted"; 
	}
	
	
	
		@GetMapping(path="/books" )
		public List<Book> getBook() {
			return  booksrepo.findAll();
		}
		
		@GetMapping(path="/books/{author}" )
		public List<Book> getBookByAuthor(@PathVariable("author") String author) {
			List<Book> findauthor= booksrepo.findByAuthor(author);
			
			      return findauthor;
			  
		}
}

