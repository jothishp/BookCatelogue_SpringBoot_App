package com.jothish.BookCatalogue.model;

import java.util.Date;

import org.hibernate.annotations.GenericGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Book {

@Id
@GeneratedValue(generator="system-uuid")
@GenericGenerator(name="system-uuid", strategy = "uuid")
private String iSBN; 
 private String title;
 private String author;
 private int quantity;
 private Date publishedDate;
 
public String getISBN() {
	return iSBN;
}
public void setISBN(String iSBN) {
	this.iSBN = iSBN;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public String getAuthor() {
	return author;
}
public void setAuthor(String author) {
	this.author = author;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public Date getPublishedDate() {
	return publishedDate;
}
public void setPublishedDate(Date publishedDate) {
	this.publishedDate = publishedDate;
}
 
 
 
 
 

 
 
 
 
 
 
 
}